
import p25_img from "./men10.png.png";
import p26_img from "./men11.png.png";
import p27_img from "./men12.png.png";
import p28_img from "./men13.png.png";
import p56_img from "./women9.png";
import p57_img from "./women10.png";
import p58_img from "./women11.png";
import p59_img from "./women12.png";

let new_arrivels = [
   {
               id: 26,
               name: "Boys Orange Colourblocked Hooded Sweatshirt",       
               image: p26_img,
               new_price: 85.0,
               old_price: 120.5,
             },
     {
               id: 25,
               name: "Boys Orange Colourblocked Hooded Sweatshirt",
               image: p25_img,
               new_price: 85.0,
               old_price: 120.5,
             },
            
             {
               id: 27,
               name: "Boys Orange Colourblocked Hooded Sweatshirt",       
               image: p27_img,
               new_price: 85.0,
               old_price: 120.5,
             },
             {
               id: 28,
               name: "Boys Orange Colourblocked Hooded Sweatshirt",
               image: p28_img,
               new_price: 85.0,
               old_price: 120.5,
             },
              {
                     id: 56,
                     name: "Boys Orange Colourblocked Hooded Sweatshirt",
                     image: p56_img,
                     new_price: 85.0,
                     old_price: 120.5,
                   },
                   {
                     id: 57,
                     name: "Boys Orange Colourblocked Hooded Sweatshirt",                
                     image: p57_img,
                     new_price: 85.0,
                     old_price: 120.5,
                   },
                   {
                     id: 58,
                     name: "Boys Orange Colourblocked Hooded Sweatshirt",
                    
                     image: p58_img,
                     new_price: 85.0,
                     old_price: 120.5,
                   },
                   {
                     id: 59,
                     name: "Boys Orange Colourblocked Hooded Sweatshirt",
                    
                     image: p59_img,
                     new_price: 85.0,
                     old_price: 120.5,
                   },
  ];
  
  export default new_arrivels;
  