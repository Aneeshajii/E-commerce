import p1_img from "./bed.png";
import p2_img from "./bed2.png";
import p3_img from "./bed3.png";
import p4_img from "./bed4.png";
import p25_img from "./men10.png.png";
import p26_img from "./men11.png.png";
import p27_img from "./men12.png.png";
import p28_img from "./men13.png.png";
import p60_img from "./women13.png";
import p61_img from "./women14.png";
import p62_img from "./women15.png";
import p63_img from "./women16.png";



let data_product = [
  {
    id:1,
    name:"Womens Cristial Black Jacket for Winter",
    image:p1_img,
    new_price:80.00,
    old_price:120,
  },
  {id:2,
    name:"Striped Flutter Full sleeve White Cotton Crop Top",
    image:p2_img,
    new_price:300,
    old_price:500,
  },
  {id:3,
    name:"Matt Red full sleeve Hoody for Womens",
    image:p3_img,
    new_price:1200,
    old_price:1999,
  },
  {id:4,
    name:"Stylish long Top with curly sleeve  for Womens",
    image:p4_img,
    new_price:999,
    old_price:1500,
  },
   {
          id: 25,
          name: "Boys Orange Colourblocked Hooded Sweatshirt",
          image: p25_img,
          new_price: 85.0,
          old_price: 120.5,
        },
        {
          id: 26,
          name: "Boys Orange Colourblocked Hooded Sweatshirt",       
          image: p26_img,
          new_price: 85.0,
          old_price: 120.5,
        },
        {
          id: 27,
          name: "Boys Orange Colourblocked Hooded Sweatshirt",       
          image: p27_img,
          new_price: 85.0,
          old_price: 120.5,
        },
        {
          id: 28,
          name: "Boys Orange Colourblocked Hooded Sweatshirt",
          image: p28_img,
          new_price: 85.0,
          old_price: 120.5,
        },
        {
                id: 60,
                name: "Boys Orange Colourblocked Hooded Sweatshirt",
                image: p60_img,
                new_price: 85.0,
                old_price: 120.5,
              },
              {
                id: 61,
                name: "Boys Orange Colourblocked Hooded Sweatshirt",             
                image: p61_img,
                new_price: 85.0,
                old_price: 120.5,
              },
              {
                id: 62,
                name: "Boys Orange Colourblocked Hooded Sweatshirt",         
                image: p62_img,
                new_price: 85.0,
                old_price: 120.5,
              },
              {
                id: 63,
                name: "Boys Orange Colourblocked Hooded Sweatshirt",              
                image: p63_img,
                new_price: 85.0,
                old_price: 120.5,
              }
];

export default data_product;